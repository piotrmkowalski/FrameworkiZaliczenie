import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dodaj-artykul',
  templateUrl: './dodaj-artykul.component.html',
  styleUrls: ['./dodaj-artykul.component.css']
})
export class DodajArtykulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
