import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-naglowek',
  templateUrl: './naglowek.component.html',
  styleUrls: ['./naglowek.component.css']
})
export class NaglowekComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
