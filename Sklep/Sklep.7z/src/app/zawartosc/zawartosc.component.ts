import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zawartosc',
  templateUrl: './zawartosc.component.html',
  styleUrls: ['./zawartosc.component.css']
})
export class ZawartoscComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
